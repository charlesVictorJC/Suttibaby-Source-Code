package com.example.ajay.suttibaby.apis;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Created by adhi on 15/7/17.
 */

public interface Apis {
    @FormUrlEncoded
    @POST("public/{path}")
    Call<ApiResponse> insertUpdateData(
                                       @Path("path") String apiPath,
                                       @Field("id") Integer rowId,
                                       @Field("plan") String plan,
                                       @Field("dob") String dob,
                                       @Field("birthtime") String birthtime,
                                       @Field("gender") String gender,
                                       @Field("birthplace") String birthplace,
                                       @Field("birthdistrict") String birthdistrict,
                                       @Field("birthstate") String birthstate,
                                       @Field("birthcountry") String birthcountry,
                                       @Field("fathername") String fathername,
                                       @Field("mothername") String mothername,
                                       @Field("notes") String notes,
                                       @Field("yourname") String yourname,
                                       @Field("doorno") String doorno,
                                       @Field("street") String street,
                                       @Field("city") String city,
                                       @Field("district") String district,
                                       @Field("state") String state,
                                       @Field("country") String country,
                                       @Field("zipcode") int zipcode,
                                       @Field("mobileno") long mobileno,
                                       @Field("email") String email,
                                       @Field("amount") int amount);



}
