package com.example.ajay.suttibaby;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import static com.example.ajay.suttibaby.apis.UserDetail.INTENT_PLAN_AMOUNT;
import static com.example.ajay.suttibaby.apis.UserDetail.INTENT_PLAN_ID;
import static com.example.ajay.suttibaby.apis.UserDetail.PLAN_BASIC_1_AMOUNT;
import static com.example.ajay.suttibaby.apis.UserDetail.PLAN_BASIC_1_ID;

/**
 * Created by ajay on 03-Jul-17.
 */

public class Pop extends Activity {

    Button g1,o1;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pop);

        g1=(Button)findViewById(R.id.g1);
        o1=(Button)findViewById(R.id.o1);


        g1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a=new Intent(getApplicationContext(),FirstActivity.class);
                startActivity(a);
                finish();
            }
        });
o1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent b=new Intent(getApplicationContext(),MainActivity.class);
        b.putExtra(INTENT_PLAN_AMOUNT,PLAN_BASIC_1_AMOUNT);
        b.putExtra(INTENT_PLAN_ID,PLAN_BASIC_1_ID);
        startActivity(b);
    }
});
    }
}