package com.example.ajay.suttibaby.utils;

import android.app.ProgressDialog;
import android.content.Context;

/**
 * Created by Madhur on 05-05-2017.
 */

public class ProgressDialogUtil {

    private static ProgressDialog mInstance;

    public static void setMessage(Context context, String message) {
        if (mInstance == null) {
            mInstance = new ProgressDialog(context);
            mInstance.setCancelable(false);
            mInstance.setCanceledOnTouchOutside(false);
            mInstance.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        }
        if (mInstance != null) {
            mInstance.setMessage(message);
            if (!mInstance.isShowing()) {
                mInstance.show();
            }
        }
    }

    public static void dismiss() {
        if (mInstance != null && mInstance.isShowing()) {
            mInstance.dismiss();
            mInstance = null;
        }
    }
}
