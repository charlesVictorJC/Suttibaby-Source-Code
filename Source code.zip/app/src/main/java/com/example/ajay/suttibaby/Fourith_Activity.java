package com.example.ajay.suttibaby;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.ajay.suttibaby.apis.UserDetail;
import com.example.ajay.suttibaby.ccavenue.Utility.AvenuesParams;
import com.example.ajay.suttibaby.ccavenue.Utility.Constants;
import com.example.ajay.suttibaby.ccavenue.Utility.ServiceUtility;
import com.example.ajay.suttibaby.ccavenue.WebViewActivity;

import static com.example.ajay.suttibaby.R.string.currency;
import static com.example.ajay.suttibaby.apis.UserDetail.INTENT_USER_DETAILS;

public class Fourith_Activity extends Activity {
    Button back,paynow;
    UserDetail userDetail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fourith_);

        if (getIntent() != null){
            userDetail = (UserDetail)getIntent().getSerializableExtra(UserDetail.INTENT_USER_DETAILS);
        }
        back=(Button)findViewById(R.id.backedit);
        paynow=(Button)findViewById(R.id.paynow);
        TextView tvDob = (TextView) findViewById(R.id.tvDob);
        TextView tvDot = (TextView) findViewById(R.id.tvDot);
        TextView tvGender = (TextView) findViewById(R.id.tvGender);
        TextView tvBPlace = (TextView) findViewById(R.id.tvBPlace);
        TextView tvBDistrict = (TextView) findViewById(R.id.tvBDistrict);
        TextView tvBCountry = (TextView) findViewById(R.id.tvBCountry);
        TextView tvFatherName = (TextView) findViewById(R.id.tvFatherName);
        TextView tvMotherName = (TextView) findViewById(R.id.tvMotherName);
        TextView tvNote = (TextView) findViewById(R.id.tvNote);
        TextView tvFullName = (TextView) findViewById(R.id.tvFullName);
        TextView tvDoorNo = (TextView) findViewById(R.id.tvDoorNo);
        TextView tvStreet = (TextView) findViewById(R.id.tvStreet);
        TextView tvCity = (TextView) findViewById(R.id.tvCity);
        TextView tvDistrict= (TextView) findViewById(R.id.tvDistrict);
        TextView tvState = (TextView) findViewById(R.id.tvState);
        TextView tvCountry = (TextView) findViewById(R.id.tvCountry);
        TextView tvPincode = (TextView) findViewById(R.id.tvPincode);
        TextView tvMobile = (TextView) findViewById(R.id.tvMobile);
        TextView tvEmail = (TextView) findViewById(R.id.tvEmail);

        if (userDetail != null) {
            tvDob.setText(userDetail.getBaby_dob());
            tvDot.setText(userDetail.getFormattedBabyBirthTime());
            tvGender.setText(userDetail.getGender());
            tvBPlace.setText(userDetail.getBirth_place());
            tvBDistrict.setText(userDetail.getBirth_district());
            tvBCountry.setText(userDetail.getBirth_country());
            tvFatherName.setText(userDetail.getFather_full_name());
            tvMotherName.setText(userDetail.getMother_full_name());
            tvFullName.setText(userDetail.getFull_name());
            tvNote.setText(userDetail.getMessage());
            tvDoorNo.setText(userDetail.getDoor_no());
            tvStreet.setText(userDetail.getStreet_area());
            tvCity.setText(userDetail.getCity());
            tvDistrict.setText(userDetail.getDistrict());
            tvState.setText(userDetail.getState());
            tvCountry.setText(userDetail.getCountry());
            tvPincode.setText(userDetail.getPin_code());
            tvMobile.setText(userDetail.getMob_num());
            tvEmail.setText(userDetail.getEmail());
        }
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        paynow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Fourith_Activity.this,WebViewActivity.class);
                intent.putExtra(AvenuesParams.ACCESS_CODE,
                        ServiceUtility.chkNull(Constants.VALUE_ACCESS_CODE).toString());
                intent.putExtra(AvenuesParams.MERCHANT_ID,
                        ServiceUtility.chkNull(Constants.VALUE_MERCHANT_ID).toString().trim());
                intent.putExtra(AvenuesParams.ORDER_ID, ServiceUtility.chkNull("Babyname-"+String.valueOf(userDetail.getId())).toString().trim());//
                intent.putExtra(AvenuesParams.AMOUNT, ServiceUtility.chkNull(userDetail.getAmount()).toString().trim());
                //intent.putExtra(AvenuesParams.ORDER_ID, ServiceUtility.chkNull("Babyname-993").toString().trim());//
                //intent.putExtra(AvenuesParams.AMOUNT, ServiceUtility.chkNull(1).toString().trim());
                intent.putExtra(AvenuesParams.CURRENCY,
                        ServiceUtility.chkNull(Constants.VALUE_CURRENCY).toString().trim());
                intent.putExtra(AvenuesParams.REDIRECT_URL,
                        ServiceUtility.chkNull(Constants.VALUE_REDIRECT_URL).toString().trim());
                intent.putExtra(AvenuesParams.CANCEL_URL,
                        ServiceUtility.chkNull(Constants.VALUE_CANCEL_URL).toString().trim());
                intent.putExtra(AvenuesParams.RSA_KEY_URL,
                        ServiceUtility.chkNull(Constants.VALUE_RSAKEY_URL).toString().trim());
                startActivity(intent);
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent =new Intent(this,MainActivity.class);
        intent.putExtra(INTENT_USER_DETAILS,userDetail);
        startActivity(intent);
        finish();
    }
}
