package com.example.ajay.suttibaby.utils;



import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

import com.example.ajay.suttibaby.R;


public class AlertDialogUtility
 {
	 public static AlertDialog dialog;
	 public static void showNetworkError(Context context) {
		 if(context==null && dialog!=null&&dialog.isShowing())
			 return;


 			AlertDialog.Builder builder = new AlertDialog.Builder(context);
 			builder.setTitle(R.string.error);
 			builder.setMessage(R.string.no_internet);

 			builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
 			    @Override
 			    public void onClick(DialogInterface dialog, int id) {
 			        dialog.cancel();
 			       
 			    }
 			});
 			
 			dialog = builder.create();
 			dialog.show();

	 }
	 public static void showError(Context context, String message) {
		 if(context==null && dialog!=null&&dialog.isShowing())
			 return;

			 AlertDialog.Builder builder = new AlertDialog.Builder(context);
			 builder.setTitle(R.string.error);
			 builder.setMessage(message);

			 builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
				 @Override
				 public void onClick(DialogInterface dialog, int id) {
					 dialog.cancel();

				 }
			 });

			 dialog = builder.create();
			 dialog.show();

	 }
	 
	 public static void showMessage(final Context context, String title, String message){
		 if(context!=null) {
			 if (title == null) title = context.getResources().getString(R.string.error);
			 AlertDialog.Builder builder = new AlertDialog.Builder(context);
			 builder.setTitle(title);
			 builder.setMessage(message);
			 builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
				 @Override
				 public void onClick(DialogInterface dialog, int id) {
					 dialog.cancel();
				 }
			 });
			 dialog = builder.create();
			 dialog.show();
		 }
	 }
}
