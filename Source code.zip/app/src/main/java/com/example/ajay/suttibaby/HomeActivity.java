package com.example.ajay.suttibaby;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by ajay on 12-Jul-17.
 */

public class HomeActivity extends Activity {

    Button b1;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity);
        TextView a=(TextView)findViewById(R.id.t11);
        a.setText(Html.fromHtml(getString(R.string.text21)));

        TextView b=(TextView)findViewById(R.id.t12);
        b.setText(Html.fromHtml(getString(R.string.text22)));

        TextView c=(TextView)findViewById(R.id.t13);
        c.setText(Html.fromHtml(getString(R.string.text23)));

        TextView d=(TextView)findViewById(R.id.t14);
        d.setText(Html.fromHtml(getString(R.string.text24)));

        TextView e=(TextView)findViewById(R.id.t15);
        e.setText(Html.fromHtml(getString(R.string.text25)));

        TextView f=(TextView)findViewById(R.id.t16);
        f.setText(Html.fromHtml(getString(R.string.text26)));

        TextView g=(TextView)findViewById(R.id.t17);
        g.setText(Html.fromHtml(getString(R.string.text27)));

        TextView h=(TextView)findViewById(R.id.t18);
        h.setText(Html.fromHtml(getString(R.string.text28)));

        TextView i=(TextView)findViewById(R.id.t19);
       i.setText(Html.fromHtml(getString(R.string.text29)));

        b1=(Button)findViewById(R.id.g11);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a=new Intent(getApplicationContext(),FirstActivity.class);
                startActivity(a);
            }
        });
    }
}