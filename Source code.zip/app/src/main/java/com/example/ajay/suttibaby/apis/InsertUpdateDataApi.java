package com.example.ajay.suttibaby.apis;

import android.content.Context;

import com.example.ajay.suttibaby.R;
import com.example.ajay.suttibaby.utils.Utility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by adhi on 15/7/17.
 */

public class InsertUpdateDataApi {
    private final String TAG = getClass().getSimpleName();
    private Context mContext;
    private InsertUpdateDataApiListener mInsertUpdateDataApiListener;
    private String plan, dob, birthtime, gender,  birthplace,  birthdistrict,
            birthstate,   birthcountry, fathername, mothername, notes, yourname,
            doorno, street, city, district,  state, country, email,apiPath;
    private int amount,zipcode;
    private Integer rowId;
    private long mobileno;
    public interface InsertUpdateDataApiListener {
        void onInsertUpdateDataSuccess(ApiResponse apiResponse);
        void onInsertUpdateDataFailure(String errorMessage);
    }

    public InsertUpdateDataApi(Context context, InsertUpdateDataApiListener insertUpdateDataApiListener,
                               String apiPath, Integer rowId, String plan, String dob,
                               String birthtime, String gender, String birthplace,
                               String birthdistrict, String birthstate,
                               String birthcountry, String fathername, String mothername,
                               String notes, String yourname, String doorno,
                               String street, String city, String district,
                               String state, String country, int zipcode,
                               long mobileno, String email, int amount){
        mContext = context;
        mInsertUpdateDataApiListener = insertUpdateDataApiListener;
        this.apiPath = apiPath;
        this.rowId = rowId;
        this.plan = plan;
        this.dob = dob;
        this.birthtime = birthtime;
        this.gender= gender;
        this.birthplace= birthplace;
        this.birthdistrict=birthdistrict;
        this.birthstate=birthstate;
        this.birthcountry=birthcountry;
        this.fathername=fathername;
        this.mothername= mothername;
        this.notes= notes;
        this.yourname = yourname;
        this.doorno = doorno;
        this.street = street;
        this.city= city;
        this.district = district;
        this.state = state;
        this.country =country;
        this.zipcode = zipcode;
        this.mobileno = mobileno;
        this.email = email;
        this.amount=amount;
    }
    public void insertData(){
        if (mContext == null) return;
        if (!Utility.isOnline(mContext)) {
            mInsertUpdateDataApiListener.onInsertUpdateDataFailure(mContext.getString(R.string.no_network));
            return;
        }

        Apis apis = ApiClient.getClient().create(Apis.class);
        Call<ApiResponse> insertDataApiCall =
                apis.insertUpdateData(apiPath, rowId,plan, dob, birthtime, gender,  birthplace,
                        birthdistrict, birthstate,   birthcountry, fathername, mothername, notes,
                        yourname, doorno, street, city, district,  state, country, zipcode,
                        mobileno, email, amount);

        insertDataApiCall.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                ApiResponse apiResponse = response.body();
                if (response.isSuccessful()){
                    if (apiResponse != null){
                        if (apiResponse.getStatus() == ApiResponse.SUCCEESS){
                            mInsertUpdateDataApiListener.onInsertUpdateDataSuccess(apiResponse);
                        }
                        else {
                            mInsertUpdateDataApiListener.onInsertUpdateDataFailure(apiResponse.getMessage());
                        }
                    }
                }
                else {
                    mInsertUpdateDataApiListener.onInsertUpdateDataFailure(response.message()+ ". Please try again.");
                }

            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                mInsertUpdateDataApiListener.onInsertUpdateDataFailure(t.getMessage());
            }
        });
    }
}
