package com.example.ajay.suttibaby.ccavenue;


public interface Communicator  {
    public void respond(String data);
    public void actionSelected(String data);
}
