package com.example.ajay.suttibaby.apis;

import android.util.Log;

import com.example.ajay.suttibaby.utils.Utility;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by adhi on 15/7/17.
 */
public class UserDetail implements Serializable {



    public static final String INTENT_USER_DETAILS="userdetails";
    public static final String INTENT_PLAN_ID="planid";
    public static final String INTENT_PLAN_AMOUNT="amount";


    public static final String  PLAN_BASIC_1_ID="BASIC 1";
    public static final int  PLAN_BASIC_1_AMOUNT=1000;

    public static final String  PLAN_BASIC_2_ID="BASIC 2";
    public static final int  PLAN_BASIC_2_AMOUNT=2000;

    public static final String  PLAN_BASIC_3_ID="BASIC 3";
    public static final int  PLAN_BASIC_3_AMOUNT=3000;

    public static final String  PLAN_GENERAL_ID="GENERAL";
    public static final int  PLAN_GENERAL_AMOUNT=4000;

    public static final String  PLAN_PREMIUM_ID="PREMIUM";
    public static final int  PLAN_PREMIUM_AMOUNT=6000;

    public static final String  PLAN_ROYAL_BABY_ID="ROYAL BABY";
    public static final int  PLAN_ROYAL_BABY_AMOUNT=9000;


    /**
     * id : 943
     * is_plan : Basic 1
     * amount : 1000
     * baby_dob : 2012-03-12
     * baby_birthtime : 05:00:00
     * gender : male
     * birth_place : cbe
     * birth_district : cbe
     * birth_state : tn
     * birth_country : in
     * father_full_name : dsgsdg
     * mother_full_name : dgsgsd
     * message : dgsgsd
     * full_name : null
     * door_no : dd
     * street_area : cbe
     * city : cbe
     * district : cbe
     * state : tn
     * country : in
     * pin_code : 12345
     * mob_num : dddd
     * email : joseph@gmail.com
     */
    @SerializedName("id")
    private int id;
    @SerializedName("is_plan")
    private String is_plan;
    @SerializedName("amount")
    private int amount;
    @SerializedName("baby_dob")
    private String baby_dob;
    @SerializedName("baby_birthtime")
    private String baby_birthtime;
    @SerializedName("gender")
    private String gender;
    @SerializedName("birth_place")
    private String birth_place;
    @SerializedName("birth_district")
    private String birth_district;
    @SerializedName("birth_state")
    private String birth_state;
    @SerializedName("birth_country")
    private String birth_country;
    @SerializedName("father_full_name")
    private String father_full_name;
    @SerializedName("mother_full_name")
    private String mother_full_name;
    @SerializedName("message")
    private String message;
    @SerializedName("full_name")
    private String full_name;
    @SerializedName("door_no")
    private String door_no;
    @SerializedName("street_area")
    private String street_area;
    @SerializedName("city")
    private String city;
    @SerializedName("district")
    private String district;
    @SerializedName("state")
    private String state;
    @SerializedName("country")
    private String country;
    @SerializedName("pin_code")
    private String pin_code;
    @SerializedName("mob_num")
    private String mob_num;
    @SerializedName("email")
    private String email;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIs_plan() {
        return is_plan;
    }

    public void setIs_plan(String is_plan) {
        this.is_plan = is_plan;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getBaby_dob() {
        return baby_dob;
    }

    public void setBaby_dob(String baby_dob) {
        this.baby_dob = baby_dob;
    }

    public String getBaby_birthtime(){
        return baby_birthtime;
    }
    public String getFormattedBabyBirthTime() {
        if (!Utility.nullCheck(baby_birthtime)){
            return "";
        }
        String _12HourFomat;
        SimpleDateFormat _24HourSDF = new SimpleDateFormat("HH:mm:ss");
        SimpleDateFormat _12HourSDF = new SimpleDateFormat("hh:mm");
        Date _24HourDt = null;
        try {
            _24HourDt = _24HourSDF.parse(baby_birthtime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Calendar cal = Calendar.getInstance();
        cal.setTime(_24HourDt);
        String timeMode= cal.get(Calendar.HOUR_OF_DAY) >= 12 ?"PM":"AM";
        _12HourFomat = _12HourSDF.format(_24HourDt);
        Log.e(getClass().getSimpleName(), " _12HourFomat = "
                +_12HourFomat+"\t _24HourFormat = "+baby_birthtime);
        return (_12HourFomat+" "+timeMode);
    }

    public void setBaby_birthtime(String baby_birthtime) {
        this.baby_birthtime = baby_birthtime;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBirth_place() {
        return birth_place;
    }

    public void setBirth_place(String birth_place) {
        this.birth_place = birth_place;
    }

    public String getBirth_district() {
        return birth_district;
    }

    public void setBirth_district(String birth_district) {
        this.birth_district = birth_district;
    }

    public String getBirth_state() {
        return birth_state;
    }

    public void setBirth_state(String birth_state) {
        this.birth_state = birth_state;
    }

    public String getBirth_country() {
        return birth_country;
    }

    public void setBirth_country(String birth_country) {
        this.birth_country = birth_country;
    }

    public String getFather_full_name() {
        return father_full_name;
    }

    public void setFather_full_name(String father_full_name) {
        this.father_full_name = father_full_name;
    }

    public String getMother_full_name() {
        return mother_full_name;
    }

    public void setMother_full_name(String mother_full_name) {
        this.mother_full_name = mother_full_name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getFull_name() {
        return full_name;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public String getDoor_no() {
        return door_no;
    }

    public void setDoor_no(String door_no) {
        this.door_no = door_no;
    }

    public String getStreet_area() {
        return street_area;
    }

    public void setStreet_area(String street_area) {
        this.street_area = street_area;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPin_code() {
        return pin_code;
    }

    public void setPin_code(String pin_code) {
        this.pin_code = pin_code;
    }

    public String getMob_num() {
        return mob_num;
    }

    public void setMob_num(String mob_num) {
        this.mob_num = mob_num;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
