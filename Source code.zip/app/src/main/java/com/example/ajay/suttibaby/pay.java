package com.example.ajay.suttibaby;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class pay extends Activity {
    private WebView mywebView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay);
        mywebView=(WebView)findViewById(R.id.web);



        WebSettings webSettings=mywebView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        mywebView.loadUrl("https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction");
        mywebView.setWebViewClient(new WebViewClient());

    }


    public void onBackPressed() {

        if(mywebView.canGoBack())
        {

            mywebView.goBack();

        }
        else{

            super.onBackPressed();

        }

    }}