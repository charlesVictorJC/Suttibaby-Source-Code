package com.example.ajay.suttibaby;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Log;
import android.util.Patterns;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.example.ajay.suttibaby.apis.ApiClient;
import com.example.ajay.suttibaby.apis.ApiResponse;
import com.example.ajay.suttibaby.apis.InsertUpdateDataApi;
import com.example.ajay.suttibaby.apis.UserDetail;
import com.example.ajay.suttibaby.ccavenue.Utility.Constants;
import com.example.ajay.suttibaby.utils.AlertDialogUtility;
import com.example.ajay.suttibaby.utils.ProgressDialogUtil;
import com.example.ajay.suttibaby.utils.Utility;
import com.wdullaer.materialdatetimepicker.time.TimePickerDialog;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import static com.basgeekball.awesomevalidation.ValidationStyle.COLORATION;
import static com.example.ajay.suttibaby.apis.UserDetail.INTENT_USER_DETAILS;

public class MainActivity extends Activity implements View.OnClickListener ,InsertUpdateDataApi.InsertUpdateDataApiListener, TimePickerDialog.OnTimeSetListener, View.OnTouchListener {


    private  final String TAG =getClass().getSimpleName();
    TextView daye2;
    TextView p1;
    TextView RandomNumber;
    Spinner spinner, spGender;
    String format;
    Button b1, clearBtn;
    ImageButton refreshBtn, dayb1, dayb2;
    EditText et_birth_place, et_birth_district, et_birth_state, et_birth_country, et_father_name, et_mother_name, et_note, et_full_name, et_door_no, et_street, et_city, et_district, et_state, et_country, et_pincode, et_mobile_no, et_email, ee18;
    public EditText et_security_code;
    private int rnumber;
    private int mYear, mMonth, mDay, mHour, mMinute;
    private int ampm;
    private boolean valid;
    private String StringDateformat_US;
    Spinner s4, s5, s6;
    String selectedItem = "";
    AwesomeValidation formValidation;

    private InsertUpdateDataApi insertUpdateDataApi;
    private String planId;
    private int amount;
    private EditText et_birth_time,etDob;
    private AutoCompleteTextView atv_gender;
    private Button submitBtn;
    private Context mContext;
    private String _12HourFomat,_24HourFormat;
    private ArrayAdapter<String> genderAdapter;

    private UserDetail userDetail;
    private Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = MainActivity.this;
        //  findAllViewsId();
        intent = getIntent();
        if (intent != null){
            if (intent.hasExtra(UserDetail.INTENT_PLAN_ID))
                planId = intent.getStringExtra(UserDetail.INTENT_PLAN_ID);
            if (intent.hasExtra(UserDetail.INTENT_PLAN_AMOUNT))
                amount = intent.getIntExtra(UserDetail.INTENT_PLAN_AMOUNT,amount);
        }
        setFormValidationStyle();
        addFormValidation();

        //    b1=(Button)findViewById(R.id.pay);
        clearBtn = (Button) findViewById(R.id.clear);
        et_birth_time = (EditText)findViewById(R.id.et_birth_time);
        RandomNumber = (TextView) findViewById(R.id.randam);
        refreshBtn = (ImageButton) findViewById(R.id.refresh_btn);
        et_security_code = (EditText) findViewById(R.id.et_security_code);
        rnumber = rnumber();
        RandomNumber.setText("" + rnumber);

        atv_gender = (AutoCompleteTextView)findViewById(R.id.atv_gender);
        etDob = (EditText) findViewById(R.id.etDob);
        submitBtn = (Button) findViewById(R.id.btn_submit);
        spGender = (Spinner) findViewById(R.id.spGender);
        et_birth_place = (EditText) findViewById(R.id.et_birth_place);
        et_birth_district = (EditText) findViewById(R.id.et_birth_district);
        et_birth_state = (EditText) findViewById(R.id.et_birth_state);
        et_birth_country = (EditText) findViewById(R.id.et_birth_country);
        et_father_name = (EditText) findViewById(R.id.et_father_name);
        et_mother_name = (EditText) findViewById(R.id.et_mother_name);
        et_note = (EditText) findViewById(R.id.et_note);
        et_full_name = (EditText) findViewById(R.id.et_full_name);
        et_door_no = (EditText) findViewById(R.id.et_door_no);
        et_street = (EditText) findViewById(R.id.et_street);
        et_city = (EditText) findViewById(R.id.et_city);
        et_district = (EditText) findViewById(R.id.et_district);
        et_state = (EditText) findViewById(R.id.et_state);
        et_country = (EditText) findViewById(R.id.et_country);
        et_pincode = (EditText) findViewById(R.id.et_pincode);
        et_mobile_no = (EditText) findViewById(R.id.et_mobile_no);
        et_email = (EditText) findViewById(R.id.et_email);
        et_mobile_no.setKeyListener(DigitsKeyListener.getInstance("0123456789"));
        et_mobile_no.setInputType(InputType.TYPE_CLASS_NUMBER);
        spGender = (Spinner) findViewById(R.id.spGender);

         genderAdapter= new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line,getResources().getStringArray(R.array.gender));
        atv_gender.setAdapter(genderAdapter);
        atv_gender.setThreshold(0);

        atv_gender.setOnClickListener(this);
        atv_gender.setOnTouchListener(this);
        etDob.setOnClickListener(this);
        submitBtn.setOnClickListener(this);
        clearBtn.setOnClickListener(this);
        et_birth_time.setOnClickListener(this);
        refreshBtn.setOnClickListener(this);

        if (intent !=null && intent.hasExtra(INTENT_USER_DETAILS)){
            userDetail = (UserDetail)intent.getSerializableExtra(INTENT_USER_DETAILS);
            setUserDetail();
        }
    }

    private void setFormValidationStyle() {
        formValidation = new AwesomeValidation(COLORATION);
        formValidation.setColor(Color.YELLOW);  // optional, default color is RED if not set

        // or
        //   formValidation = new AwesomeValidation(UNDERLABEL);

        // formValidation.setContext(this);  // mandatory for UNDERLABEL style

    }

    private void addFormValidation() {

        //  formValidation.addValidation(this, R.id.Birth1, Range.closed(1900, Calendar.getInstance().get(Calendar.YEAR)), R.string.textview);
        // formValidation.addValidation(this, R.id.Birth1, "[a-zA-Z0-9_-]+", R.string.textview);

        String regex =" ~`!@#\\$%\\^&\\*\\(\\)\\-_\\+=\\{\\}\\[\\]\\|\\;:\"<>,./\\?";
        String validationFormat = "[a-zA-Z0-9"+regex+"]+";
        formValidation.addValidation(this, R.id.etDob, validationFormat, R.string.ee1);
        //formValidation.addValidation(this, R.id.etDob, "[a-zA-Z0-9_-]+", R.string.ee1);
        formValidation.addValidation(this, R.id.et_birth_time, validationFormat, R.string.ee1);
        //formValidation.addValidation(this, R.id.et_birth_time, "[a-zA-Z0-9 :,;#&/]+", R.string.ee1);
        formValidation.addValidation(this, R.id.et_birth_place, validationFormat, R.string.ee1);
        formValidation.addValidation(this, R.id.atv_gender, "[a-zA-Z\\s]+", R.string.ee1);
        //formValidation.addValidation(this, R.id.et_birth_district, "[a-zA-Z\\s]+", R.string.ee2);
        formValidation.addValidation(this, R.id.et_birth_state, validationFormat, R.string.ee3);
        formValidation.addValidation(this, R.id.et_birth_country, validationFormat, R.string.ee4);
        formValidation.addValidation(this, R.id.et_father_name, validationFormat, R.string.ee5);
        formValidation.addValidation(this, R.id.et_mother_name, validationFormat, R.string.ee6);
        //formValidation.addValidation(this, R.id.et_note, "[a-zA-Z\\s]+", R.string.ee7);
        formValidation.addValidation(this, R.id.et_full_name, validationFormat, R.string.ee8);
        formValidation.addValidation(this, R.id.et_door_no, validationFormat, R.string.ee9);
        formValidation.addValidation(this, R.id.et_street,validationFormat, R.string.ee10);
        formValidation.addValidation(this, R.id.et_city, validationFormat, R.string.ee11);
    //    formValidation.addValidation(this, R.id.et_district, "[a-zA-Z\\s]+", R.string.ee12);
        formValidation.addValidation(this, R.id.et_state, validationFormat, R.string.ee13);
        formValidation.addValidation(this, R.id.et_country, validationFormat, R.string.ee14);
        formValidation.addValidation(this, R.id.et_pincode, "\\d+", R.string.ee15);
        formValidation.addValidation(this, R.id.et_mobile_no, Patterns.PHONE, R.string.ee16);
        formValidation.addValidation(this, R.id.et_email, Patterns.EMAIL_ADDRESS, R.string.ee17);
        formValidation.addValidation(this, R.id.et_security_code, "\\d+", R.string.ee19);



    }


    public static int rnumber() {

        Random generator = new Random();

        int x = generator.nextInt(90000);
        return x;


    }


    private void setUserDetail(){
        boolean isUserDetail = (userDetail != null);

        etDob.setText(isUserDetail ? userDetail.getBaby_dob() : "");
        et_birth_time.setText(isUserDetail ? userDetail.getFormattedBabyBirthTime() : "");
        et_birth_place.setText(isUserDetail ? userDetail.getBirth_place() : "");
        atv_gender.setText(isUserDetail ? userDetail.getGender(): "");
        et_birth_district.setText(isUserDetail ? userDetail.getBirth_district() : "");
        et_birth_state.setText(isUserDetail ? userDetail.getBirth_state() : "");
        et_birth_country.setText(isUserDetail ? userDetail.getBirth_country() : "");
        et_father_name.setText(isUserDetail ? userDetail.getFather_full_name() : "");
        et_mother_name.setText(isUserDetail ? userDetail.getMother_full_name() : "");
        et_note.setText(isUserDetail ? userDetail.getMessage() : "");
        et_full_name.setText(isUserDetail ? userDetail.getFull_name() : "");
        et_door_no.setText(isUserDetail ? userDetail.getDoor_no() : "");
        et_street.setText(isUserDetail ? userDetail.getStreet_area() : "");
        et_city.setText(isUserDetail ? userDetail.getCity() : "");
        et_district.setText(isUserDetail ? userDetail.getDistrict() : "");
        et_state.setText(isUserDetail ? userDetail.getState() : "");
        et_country.setText(isUserDetail ? userDetail.getCountry() : "");
        et_pincode.setText(isUserDetail ? userDetail.getPin_code() : "");
        et_mobile_no.setText(isUserDetail ? userDetail.getMob_num() : "");
        et_email.setText(isUserDetail ? userDetail.getEmail() : "");
        et_security_code.setText("");
        refreshBtn.callOnClick();
        List<String> genderList = Arrays.asList(getResources().getStringArray(R.array.gender));
        spGender.setSelection(isUserDetail ? genderList.indexOf(userDetail.getGender()):0);

    }
    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.etDob:
                setBirthDate();
                break;
            case R.id.et_birth_time:
                setBirthTime();
                break;
            case R.id.btn_submit:
                sumbitData();
                break;
            case R.id.refresh_btn:
                refreshSecurityCode();
                break;
            case R.id.clear:
                clearData();
                break;
            case R.id.atv_gender:
                genderAdapter= new ArrayAdapter<>(this,
                        android.R.layout.simple_dropdown_item_1line,getResources().getStringArray(R.array.gender));
                atv_gender.setAdapter(genderAdapter);
                atv_gender.setAdapter(genderAdapter);
                atv_gender.setThreshold(0);
                atv_gender.showDropDown();
                break;
        }
     }

    private void clearData() {
        if (userDetail != null){
            UserDetail tempUserDetail = new UserDetail();
            tempUserDetail.setId(userDetail.getId());
            tempUserDetail.setIs_plan(userDetail.getIs_plan());
            tempUserDetail.setAmount(userDetail.getAmount());
            userDetail = tempUserDetail;

        }
        setUserDetail();
       // formValidation.clear();
        /*        etDob.setText("");
                et_birth_time.setText("");
                et_birth_place.setText("");
                et_birth_district.setText("");
                et_birth_state.setText("");
                et_birth_country.setText("");
                et_father_name.setText("");
                et_mother_name.setText("");
                et_note.setText("");
                et_full_name.setText("");
                et_door_no.setText("");
                et_street.setText("");
                et_city.setText("");
                et_district.setText("");
                et_state.setText("");
                et_country.setText("");
                et_pincode.setText("");
                et_mobile_no.setText("");
                et_email.setText("");
                et_security_code.setText("");
                spGender.setSelection(0);*/
    }

    private void refreshSecurityCode() {

        rnumber = rnumber();
        RandomNumber.setText("" + rnumber);
    }

    private void sumbitData() {
        boolean isAddDataValid = formValidation.validate();
        if (isAddDataValid)
        {
            /*if (spGender.getSelectedItemPosition() == 0){
                AlertDialogUtility.showError(mContext,getString(R.string.error_select_gender));
                return;
            }
            else*/ if (!RandomNumber.getText().toString().trim().equals(et_security_code.getText().toString().trim())){
                AlertDialogUtility.showError(mContext,getString(R.string.error_security_code));
                return;
            }
            boolean isUserDetailAvailable =(userDetail  != null);
            ProgressDialogUtil.setMessage(mContext,
                    isUserDetailAvailable ? getString(R.string.pd_updating_data)
                                          :getString(R.string.pd_inserting_data));
            insertUpdateDataApi = new InsertUpdateDataApi(
                    mContext,
                    MainActivity.this,
                    isUserDetailAvailable ? ApiClient.UPDATE_PATH : ApiClient.INSERT_PATH ,
                    isUserDetailAvailable ? userDetail.getId() : null,
                    isUserDetailAvailable ? userDetail.getIs_plan() : planId,
                    etDob.getText().toString(),
                    getBirthTime(),
                    atv_gender.getText().toString(),
                    et_birth_place.getText().toString(),
                    et_birth_district.getText().toString(),
                    et_birth_state.getText().toString(),
                    et_birth_country.getText().toString(),
                    et_father_name.getText().toString(),
                    et_mother_name.getText().toString(),
                    et_note.getText().toString(),
                    et_full_name.getText().toString(),
                    et_door_no.getText().toString(),
                    et_street.getText().toString(),
                    et_city.getText().toString(),
                    et_district.getText().toString(),
                    et_state.getText().toString(),
                    et_country.getText().toString(),
                    Integer.parseInt(et_pincode.getText().toString()),
                    Long.parseLong(et_mobile_no.getText().toString()),
                    et_email.getText().toString(),
                    isUserDetailAvailable ? userDetail.getAmount() :amount);
            insertUpdateDataApi.insertData();
        }

    }

    private String getBirthTime(){
        if (Utility.nullCheck(_24HourFormat)){
            return _24HourFormat;
        }
        else  if (userDetail != null &&
                Utility.nullCheck(userDetail.getBaby_birthtime())){
            String  serverDate = null;
            SimpleDateFormat _24HourSDF = new SimpleDateFormat("HH:mm:ss");
            SimpleDateFormat serverSDF = new SimpleDateFormat("HH:mm");
            Date _24HourDt = null;
            try {
                _24HourDt = _24HourSDF.parse(userDetail.getBaby_birthtime());
                serverDate = serverSDF.format(_24HourDt);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return serverDate;
        }
        return null;
    }
    private void setBirthTime() {
        final Calendar now = Calendar.getInstance();
        mHour = now.get(Calendar.HOUR_OF_DAY);
        mMinute = now.get(Calendar.MINUTE);
        TimePickerDialog tpd = TimePickerDialog.newInstance(
                MainActivity.this,
                mHour,
                mMinute,
                false
        );

        tpd.setVersion(TimePickerDialog.Version.VERSION_1);
        tpd.show(getFragmentManager(), "Timepickerdialog");
    }

    private void setBirthDate() {

        // Get Current Date
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                R.style.DatePickerStyle,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        etDob.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);

                    }
                }, mYear, mMonth, mDay);


        datePickerDialog.show();
    }


    @Override
    public void onInsertUpdateDataSuccess(ApiResponse apiResponse) {
        //clearBtn.callOnClick();
        ProgressDialogUtil.dismiss();
        userDetail = apiResponse.getUserDetail();
        Intent intent =new Intent(mContext,Fourith_Activity.class);
        intent.putExtra(INTENT_USER_DETAILS,apiResponse.getUserDetail());
        startActivity(intent);
        finish();
    }

    @Override
    public void onInsertUpdateDataFailure(String errorMessage) {
        ProgressDialogUtil.dismiss();
        AlertDialogUtility.showError(mContext,errorMessage);
    }

    @Override
    public void onTimeSet(TimePickerDialog view, int hourOfDay, int minute, int second) {
        String timeMode= hourOfDay >= 12 ?"PM":"AM";
        _24HourFormat = hourOfDay+":"+minute;

        SimpleDateFormat _24HourSDF = new SimpleDateFormat("HH:mm");
        SimpleDateFormat _12HourSDF = new SimpleDateFormat("hh:mm");
        Date _24HourDt = null;
        try {
            _24HourDt = _24HourSDF.parse(_24HourFormat);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        _12HourFomat = _12HourSDF.format(_24HourDt);
        Log.e(TAG, " _12HourFomat = "+_12HourFomat+"\t _24HourFormat = "+_24HourFormat);
        et_birth_time.setText(_12HourFomat+" "+timeMode);

    }


    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        atv_gender.callOnClick();
        return false;
    }
}