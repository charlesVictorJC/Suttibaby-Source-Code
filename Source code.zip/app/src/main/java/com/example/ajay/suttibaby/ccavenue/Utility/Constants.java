package com.example.ajay.suttibaby.ccavenue.Utility;


public class Constants {
    public static final String PARAMETER_SEP = "&";
    public static final String PARAMETER_EQUALS = "=";
    public static final String VALUE_MERCHANT_ID= "54043";
    public static final String VALUE_ACCESS_CODE= "AVMI68EA60AF39IMFA";
    public static final String VALUE_CURRENCY= "INR";
    public static final String TRANS_URL = "https://secure.ccavenue.com/transaction/initTrans";
   /* public static final String VALUE_REDIRECT_URL= "https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction";
    public static final String VALUE_CANCEL_URL= "http://www.suttibaby.com";
    public static final String VALUE_RSAKEY_URL= "http://order.suttibaby.com/public/RSAResponse";*/
    //public static final String TRANS_URL = "https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction";
    public static final String VALUE_REDIRECT_URL= "http://order.suttibaby.com/public/pay/response";
    public static final String VALUE_CANCEL_URL= "http://www.suttibaby.com";
    public static final String VALUE_RSAKEY_URL= "http://order.suttibaby.com/public/RSAResponse";


    public static final String STATUS_SUCCESS_KEY= "http://order.suttibaby.com/public/babyname/final";
    public static final String STATUS_FAILURE_KEY= "http://order.suttibaby.com/public/RSAResponse";
    public static final String STATUS_CANCEL_KEY= "http://order.suttibaby.com/public/RSAResponse";

}
