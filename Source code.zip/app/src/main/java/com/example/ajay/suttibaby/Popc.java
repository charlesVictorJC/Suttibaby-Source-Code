package com.example.ajay.suttibaby;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import static com.example.ajay.suttibaby.apis.UserDetail.INTENT_PLAN_AMOUNT;
import static com.example.ajay.suttibaby.apis.UserDetail.INTENT_PLAN_ID;
import static com.example.ajay.suttibaby.apis.UserDetail.PLAN_BASIC_1_AMOUNT;
import static com.example.ajay.suttibaby.apis.UserDetail.PLAN_BASIC_1_ID;
import static com.example.ajay.suttibaby.apis.UserDetail.PLAN_BASIC_3_AMOUNT;
import static com.example.ajay.suttibaby.apis.UserDetail.PLAN_BASIC_3_ID;

/**
 * Created by ajay on 03-Jul-17.
 */

public class Popc extends Activity {
Button g3,o3;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.popc);

        g3=(Button)findViewById(R.id.g3);
        o3=(Button)findViewById(R.id.o3);



        g3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a=new Intent(getApplicationContext(),FirstActivity.class);
                startActivity(a);
                finish();
            }
        });
        o3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent b=new Intent(getApplicationContext(),MainActivity.class);
                b.putExtra(INTENT_PLAN_AMOUNT,PLAN_BASIC_3_AMOUNT);
                b.putExtra(INTENT_PLAN_ID,PLAN_BASIC_3_ID);
                startActivity(b);

            }
        });
    }
}
