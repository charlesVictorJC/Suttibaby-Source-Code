package com.example.ajay.suttibaby.ccavenue;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.example.ajay.suttibaby.FirstActivity;
import com.example.ajay.suttibaby.HomeActivity;
import com.example.ajay.suttibaby.R;


public class StatusActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);

        Intent mainIntent = getIntent();
        TextView tv_status= (TextView) findViewById(R.id.tv_status);
        tv_status.setText(mainIntent.getStringExtra("transStatus"));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(this,HomeActivity.class));
        finishAffinity();
    }
}
