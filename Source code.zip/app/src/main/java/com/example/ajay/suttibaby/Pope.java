package com.example.ajay.suttibaby;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import static com.example.ajay.suttibaby.apis.UserDetail.INTENT_PLAN_AMOUNT;
import static com.example.ajay.suttibaby.apis.UserDetail.INTENT_PLAN_ID;
import static com.example.ajay.suttibaby.apis.UserDetail.PLAN_BASIC_1_AMOUNT;
import static com.example.ajay.suttibaby.apis.UserDetail.PLAN_BASIC_1_ID;
import static com.example.ajay.suttibaby.apis.UserDetail.PLAN_PREMIUM_AMOUNT;
import static com.example.ajay.suttibaby.apis.UserDetail.PLAN_PREMIUM_ID;

/**
 * Created by ajay on 03-Jul-17.
 */

public class Pope extends Activity {

    Button g5,o5;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pope);


        g5=(Button)findViewById(R.id.g5);
        o5=(Button)findViewById(R.id.o5);


        g5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a=new Intent(getApplicationContext(),FirstActivity.class);
                 startActivity(a);
                finish();
            }
        });

        o5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a=new Intent(getApplicationContext(),MainActivity.class);
                a.putExtra(INTENT_PLAN_AMOUNT,PLAN_PREMIUM_AMOUNT);
                a.putExtra(INTENT_PLAN_ID,PLAN_PREMIUM_ID);
                startActivity(a);

            }
        });
    }
}
