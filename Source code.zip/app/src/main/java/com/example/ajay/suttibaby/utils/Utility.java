package com.example.ajay.suttibaby.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

/**
 * Created by adhi on 15/7/17.
 */

public class Utility { public static boolean nullCheck(String value) {
    return value != null && value.trim().length() != 0
            && !value.trim().contentEquals("null")
            && !value.trim().contentEquals("__NULL__")
            && !value.trim().contentEquals("false")
            && !value.trim().contentEquals("FALSE");
}

    public static boolean isOnline(Context context) {
        if (context == null) return false;

        ConnectivityManager cm = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }
}
