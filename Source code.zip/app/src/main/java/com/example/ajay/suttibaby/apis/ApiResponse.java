package com.example.ajay.suttibaby.apis;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by adhi on 15/7/17.
 */

public class ApiResponse {

    /**
     * status : 1
     * message : Your Data has posted successfully
     * user_details : [{"id":919,"amount":1000,"payment_status":"null","paid_at":null,"payment_mode":null,"is_plan":"basic 23","is_name":"null","full_name":"null","initial":"null","first_name":"null","last_name":"null","middle_name":"null","door_no":"123","street_area":"cbe","city":"cbe","district":"cbe","state":"tn","country":"in","pin_code":"123","mob_num":"1234567890","alt_num":null,"country_code":null,"area_code":null,"email":"joseph@gmail.com","number":null,"is_baby_dob":"yes","baby_dob":"0198-03-23","is_baby_birthtime":"yes","is_baby_birthtime1":null,"is_baby_birthtime2":null,"baby_birthtime":"15:00:00","baby_birthtime1":null,"baby_birthtime2":null,"is_submitted":0,"nature_baby_delivery":null,"gender":"male","gender1":null,"gender2":null,"is_baby_blood_group":null,"baby_blood_group":null,"is_baby_blood_group1":null,"baby_blood_group1":null,"is_baby_blood_group2":null,"baby_blood_group2":null,"baby_weight":null,"baby_weight1":null,"baby_weight2":null,"birth_place":"cbe","birth_district":"cbe","birth_state":"tn","birth_country":"in","is_baby_birth_star":null,"baby_birth_star":null,"is_baby_birth_star1":null,"baby_birth_star1":null,"is_baby_birth_star2":null,"baby_birth_star2":null,"baby_father":null,"is_baby_father_name":null,"father_full_name":"dsgsdg","father_initial":null,"father_first_name":null,"father_middle_name":null,"father_last_name":null,"is_baby_father_dob":null,"baby_father_dob":null,"is_baby_father_blood_group":null,"baby_father_blood_group":null,"baby_mother":null,"is_baby_mother_name":null,"mother_initial":null,"mother_full_name":"dgsgsd","mother_first_name":null,"mother_middle_name":null,"mother_last_name":null,"is_baby_mother_dob":null,"baby_mother_dob":null,"is_baby_mother_blood_group":null,"baby_mother_blood_group":null,"native_baby_father":null,"is_wedding_date":null,"wedding_date":null,"paternal_father_name":null,"is_father_father_name":null,"father_father_full_name":null,"father_father_initial":null,"father_father_first_name":null,"father_father_middle_name":null,"father_father_last_name":null,"paternal_mother_name":null,"is_father_mother_name":null,"father_mother_full_name":null,"father_mother_initial":null,"father_mother_first_name":null,"father_mother_middle_name":null,"father_mother_last_name":null,"maternal_father_name":null,"is_mother_father_name":null,"mother_father_full_name":null,"mother_father_initial":null,"mother_father_first_name":null,"mother_father_middle_name":null,"mother_father_last_name":null,"maternal_mother_name":null,"is_mother_mother_name":null,"mother_mother_full_name":null,"mother_mother_initial":null,"mother_mother_first_name":null,"mother_mother_middle_name":null,"mother_mother_last_name":null,"mob_num_father":null,"email_father":null,"country_father":null,"message":"dgsgsd","updated_at":null,"created_at":"2017-07-15","isd_code":null,"is_completed":"2017-07-15 07:14:23","isd_code1":null,"user_login":null,"order_status":null,"servicename":null}]
     */

    public static final int SUCCEESS =1;
    public static final int FAILURE =0;
    @SerializedName("status")
    private int status;
    @SerializedName("message")
    private String message;
    @SerializedName("user_details")
    private List<UserDetail> user_details;
    private  UserDetail user_detail;
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<UserDetail> getUserDetails() {
        return user_details;
    }
    public  UserDetail getUserDetail() {
        if (user_details.size()!=0)
            user_detail = user_details.get(0);
        return user_detail;
    }
    public void setUserDetail(List<UserDetail> user_details) {
        this.user_details = user_details;
    }


}
