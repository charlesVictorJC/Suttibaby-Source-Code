package com.example.ajay.suttibaby;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/**
 * Created by ajay on 25-Jun-17.
 */

public class OTPGenerate {


    static String code;
    public static String generate(){
        try {
            String strArr[]=new String[6];
            SecureRandom number = SecureRandom.getInstance("");
            // Generate 20 integers 0..20
            for (int i = 0; i < 6; i++) {
                strArr[i]=Integer.toString(number.nextInt(6));

            }
            code=convertStringArrayToString(strArr);
            // System.out.println(code);


        }

        catch (NoSuchAlgorithmException nsae) {
            // Forward to handler
        }
        return code;

    }
    private static String convertStringArrayToString(String[] strArr) {
        StringBuilder sb = new StringBuilder();
        for(String str : strArr) sb.append(str);
        return sb.toString();
    }

}



